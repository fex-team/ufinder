UFinder.LANG['zh-cn'] = {
    'labelMap':{
        'open': '打开',
        'touch': '新建文件',
        'mkdir': '新建文件夹',
        'rename': '重命名',
        'remove': '删除',
        'init': '初始化',
        'lookimage': '图片预览',
        'lookcode': '查看文本文件'
    },
    'lookimage': {

    },
    'lookcode': {

    }
};